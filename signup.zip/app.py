import datetime

from flask import Flask
from flask import g
from flask import redirect
from flask import request
from flask import session
from flask import url_for, abort, render_template, flash
from functools import wraps
from validate_email import validate_email
from peewee import *

# config - aside from our database, the rest is for use by Flask
DATABASE = 'ktestflight.db'
DEBUG = False
SECRET_KEY = 'Ao26XEy8Niz7DMsYxhcijZKI5M91wGB7'

# create a flask application - this ``app`` object will be used to handle
# inbound requests, routing them to the proper 'view' functions, etc
app = Flask(__name__)
app.config.from_object(__name__)

# create a peewee database instance -- our models will use this database to
# persist information
database = SqliteDatabase(DATABASE)

# model definitions -- the standard "pattern" is to define a base model class
# that specifies which database to use.  then, any subclasses will automatically
# use the correct storage. for more information, see:
# http://charlesleifer.com/docs/peewee/peewee/models.html#model-api-smells-like-django
class BaseModel(Model):
    class Meta:
        database = database

# the user model specifies its fields (or columns) declaratively, like django
class User(BaseModel):
    firstname = CharField()
    lastname = CharField()
    email = CharField(unique=True)
    added = BooleanField(default=False)
    join_date = DateTimeField()

    class Meta:
        db_table='users'

# simple utility function to create tables
def create_tables():
    with database:
        database.create_tables([User])

# Request handlers -- these two hooks are provided by flask and we will use them
# to create and tear down a database connection on each request.
@app.before_request
def before_request():
    g.db = database
    g.db.connect()

@app.after_request
def after_request(response):
    g.db.close()
    return response

# views -- these are the actual mappings of url to view function
@app.route('/')
def homepage():
    return render_template('signup.html')

@app.route('/signup/', methods=['POST'])
def signup():
    if request.method == 'POST' and request.form['email'] and request.form['firstname'] and request.form['lastname']:
        isValid = True
        firstname = request.form['firstname']
        lastname = request.form['lastname']
        email = request.form['email']
        if len(firstname) < 1:
            isValid = False
            flash("Invalid Firstname")
        if len(lastname) < 1:
            isValid = False
            flash("Invalid Lastname")
        if validate_email(email) is False:
            isValid = False
            flash("Invalid Email")
        if isValid:
            try:
                with database.atomic():
                    # Attempt to create the user. If the username is taken, due to the
                    # unique constraint, the database will raise an IntegrityError.
                    user = User.create(
                        firstname=request.form['firstname'],
                        lastname=request.form['lastname'],
                        email=request.form['email'],
                        join_date=datetime.datetime.utcnow())
                    user.save()

                return redirect(url_for('success'))

            except IntegrityError:
                flash('Email is already signed up')
    else:
        flash("All fields are required")

    return render_template('signup.html')

@app.route('/success/')
def success():
    return render_template('success.html')

# allow running from the command line
if __name__ == '__main__':
    create_tables()
    app.run()
